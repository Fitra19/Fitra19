<?php
session_start();
include 'config/config.php';

$id = $_GET["id"];

if(hapus($id) > 0) {
    echo "<script>
    alert('Data Berhasil di Hapus ^_^');document.location.href='index.php';
    </script>";

    } else {
        echo "<script>
        alert('Data Gagal di Hapus -_-');document.location.href='index.php';
        </script>";
    }
?>