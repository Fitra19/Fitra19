<?php
session_start();
include 'config/config.php';

$pelanggan = query("SELECT * FROM customer_072 ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <title>Data Pelanggan</title>
</head>
<body>

<!--navbar-->
<nav class="navbar navbar-expand-lg navbar-dark bg-success">
  <div class="container-fluid">
    <a class="navbar-brand fw-bold fs-4 ms-4" href="#">Cafe Perjuangan Bersama</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse justify-content-end me-5" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.php">Data Customer</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="transaksi.php">Data Transaksi</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
<!--navbar-->

<div class="container mt">
    <h1 class="text-start mt-4 fs-2">Data Customer</h1>
    <hr>
    <div>
        <a href="tambah_data.php" class="btn btn-info fw-bold" role="button">Tambah Data</a>
    </div>
    <table class="table table-striped mt-3">
        <tr class="text-center fw-bold">
            <th>ID</th>
            <th>Nama Customer</th>
            <th>Alamat</th>
            <th>No Telp</th>
            <th>Aksi</th>
        </tr>
        <?php $i = 1;?>
                    <?php foreach($pelanggan as $row) :?>
                <tr class="text-center">
                    <td><?= $i;?></td>
                    <td><?= $row ["nama_customer"];?></td>
                    <td><?= $row ["alamat"];?></td>
                    <td><?= $row ["no_telp"];?></td>
                    <td><a role="button" class="btn btn-success" href="edit_data.php?id=<?= $row ["id"];?>">Edit</a>
                        <a role="button" class="btn btn-warning" href="hapus_data.php?id=<?= $row ["id"];?>" onclick="return confirm('Yakin Ingin Menghapus Data ini ?');">Hapus</a>
                    </td>
                </tr>
                
                    <?php $i++;?>
                <?php endforeach;?>
    </table>
    </div>
    </div>
</body>
</html>
