<?php
session_start();
include 'config/config.php';
//cek tombol submit
if(isset($_POST["submit"])) {

    //cek data apakah berhasil ditambahkan
    if(tambah($_POST) > 0) {
        echo "<script>
            alert('Data Berhasil di Tambahkan ^_^');
            document.location.href='index.php';
            </script>";
       
        } else {
            echo "<script>
            alert('Data Gagal di Tambahkan -_-');
            document.location.href='index.php';
            </script>";
        }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <title>Tambah Data | Pelanggan</title>
</head>
<body>
    <div class="container mt">
    <h1 class="fw-bold fs-3 mt-3">Tambah Data</h1>
    <hr>
    <form action="" method="post" class="container-sm">
        
        <label for="nama_customer" class="form-label">Nama Customer :</label>
        <input type="text" class="form-control" name="nama_customer" placeholder="Nama Pelanggan" required/>

        <label for="alamat" class="form-label">Alamat :</label>
        <input type="text" class="form-control" name="alamat" placeholder="Alamat" required/>
        
        <label for="no_telp" class="form-label">No Telpon :</label>
        <input type="text" class="form-control" name="no_telp" placeholder="Telepon" required/>

        <button type="submit" name="submit" class="btn btn-primary mt-4">Tambah Data</button>
    </form>
    </div>
</body>
</html>