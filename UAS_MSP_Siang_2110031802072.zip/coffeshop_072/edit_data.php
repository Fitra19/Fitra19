<?php
session_start();
include 'config/config.php';

//ambi data di URL
$id = $_GET["id"];

//query data mahasiswa berdasarkan id
$sql = query("SELECT * FROM customer_072 WHERE id=$id")[0];

//cek tombol submit sudah ditekan atau belum
if(isset($_POST["submit"])) {

    //cek data apakah berhasil di ubah
    if(edit($_POST) > 0) {
        echo "<script>
        alert('Data Berhasil di Ubah ^_^');document.location.href='index.php';
        </script>";
    
    } else {
        echo "<script>
        alert('Data Gagal di Ubah -_-');document.location.href='index.php';
        </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <title>Edit Data | Pelanggan</title>
</head>
<body>
<div class="container mt">
    <h1 class="fw-bold fs-3 mt-4">Edit Data Pelanggan</h1>
    <hr>
    <form action="" method="post" class="container-sm">
        <input type="hidden" name="id" value="<?= $sql["id"];?>">

        <label for="nama_customer" class="form-label">Nama Customer :</label>
        <input type="text" class="form-control" name="nama_customer" id="nama_customer" value="<?= $sql["nama_customer"];?>" required/>

        <label for="alamat" class="form-label">Alamat :</label>
        <input type="text" class="form-control" name="alamat" id="alamat" value="<?= $sql["alamat"];?>" required/>
        
        <label for="no_telp" class="form-label">No Telpon :</label>
        <input type="text" class="form-control" name="no_telp" id="alamat" value="<?= $sql["no_telp"];?>" required/>

        <button type="submit" name="submit" class="btn btn-success mt-4">Edit Data</button>
    </form>
</body>
</html>