<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "coffeshop_072";

// Membuat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);


//function dari query(menampilkan data)
function query($query) {
    global $conn;
    $result = mysqli_query($conn, $query);
    $rows = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $rows[] = $row;
    }
    return $rows;
}

//function tambah data
function tambah($data) {
    global $conn;
    $nama_customer = htmlspecialchars($data["nama_customer"]);
    $alamat = htmlspecialchars($data["alamat"]);
    $no_telp = htmlspecialchars($data["no_telp"]);

    $query = "INSERT INTO customer_072 
    VALUES ('','$nama_customer','$alamat', '$no_telp')";
mysqli_query($conn, $query);

return mysqli_affected_rows($conn);    
}

//function edit data
function edit($data) {
    global $conn;
    $id= $data["id"];
    $nama_customer = htmlspecialchars($data["nama_customer"]);
    $alamat = htmlspecialchars($data["alamat"]);
    $no_telp = htmlspecialchars($data["no_telp"]);

    $query = "UPDATE customer_072 SET
    nama_customer='$nama_customer', alamat='$alamat', no_telp='$no_telp' WHERE id=$id";
mysqli_query($conn, $query);

return mysqli_affected_rows($conn);    
}

//function hapus data
function hapus($id) {
    global $conn;
    mysqli_query($conn, "DELETE FROM customer_072 WHERE id = $id");
    
    return mysqli_affected_rows($conn);
}


//function tambah data transaksi
function transaksi($data) {
    global $conn;
    $nama_customer = htmlspecialchars($data["nama_customer"]);
    $menu = htmlspecialchars($data["menu"]);
    $varian_rasa = htmlspecialchars($data["varian_rasa"]);
    $tanggal = htmlspecialchars($data["tanggal"]);
    $harga = htmlspecialchars($data["harga"]);

    $query = "INSERT INTO transaksi_072 
    VALUES ('','$nama_customer' ,'$menu', '$varian_rasa','$tanggal', '$harga')";
mysqli_query($conn, $query);

return mysqli_affected_rows($conn);    
}
?>