<?php
session_start();
include 'config/config.php';

$customer = query("SELECT * FROM transaksi_072 ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak Transaksi</title>
</head>
<body>
<style>
        table {
            width: 100%;
            margin-top: 20px;
        }

        table tr td {
            text-align: center;
            border: 1px solid ;
        }
</style>
    <center><h2>Data Transaksi Cafe Perjuangan Bersama</h2></center>
    <hr>
    <center><table>
        <tr>
            <th>ID</th>
            <th>Nama Customer</th>
            <th>Menu Pilihan</th>
            <th>Varian Rasa</th>
            <th>Tanggal</th> 
            <th>Harga</th>
        </tr>
        <?php $i = 1;?>
                    <?php foreach($customer as $row) :?>
                <tr>
                    <td><?= $i;?></td>
                    <td><?= $row ["nama_customer"];?></td>
                    <td><?= $row ["menu"];?></td>
                    <td><?= $row ["varian_rasa"];?></td>
                    <td><?= $row ["tanggal"];?></td>
                    <td><?= $row ["harga"];?></td>
                </tr>
                
                    <?php $i++;?>
                <?php endforeach;?>
    </table></center>
    <script>
    window.onload = function() {
        window.print();
    };
    </script>
</body>
</html>
