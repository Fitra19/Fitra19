<?php
session_start();
include 'config/config.php';

$transaksi = query("SELECT * FROM transaksi_072 ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <title>Data Transaksi | Customer</title>
</head>
<body>

<!--navbar-->
<nav class="navbar navbar-expand-lg navbar-dark bg-success">
  <div class="container-fluid">
    <a class="navbar-brand fw-bold fs-4 ms-5" href="#">Cafe Perjuangan Bersama</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse justify-content-end me-5" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.php">Data Customer</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="transaksi.php">Data Transaksi</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
<!--navbar-->
<div class="container mt">
    <h1 class="text-start mt-4 fs-2">Data Transaksi</h1>
    <hr>
    <div>
        <a href="tambah_transaksi.php" class="btn btn-info fw-bold" role="button">Tambah Data Transaksi</a>
        <a href="cetak.php" target="_blank" class="btn btn-warning fw-bold" role="button">Cetak</a>
    <table class="table table-striped mt-3">
        <tr class="text-center fw-bold">
            <th>ID</th>
            <th>Nama Customer</th>
            <th>Menu</th>
            <th>Varian Rasa</th>
            <th>Tanggal</th>
            <th>Harga</th>
        </tr>
        <?php $i = 1;?>
                    <?php foreach($transaksi as $row) :?>
                <tr class="text-center">
                    <td><?= $i;?></td>
                    <td><?= $row ["nama_customer"];?></td>
                    <td><?= $row ["menu"];?></td>
                    <td><?= $row ["varian_rasa"];?></td>
                    <td><?= $row ["tanggal"];?></td>
                    <td><?= $row ["harga"];?></td>
                </tr>
                
                    <?php $i++;?>
                <?php endforeach;?>
    </table>
    </div>

</body>
</html>
