-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 12, 2024 at 06:38 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `coffeshop_072`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer_072`
--

CREATE TABLE `customer_072` (
  `id` int(11) NOT NULL,
  `nama_customer` varchar(25) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `no_telp` varchar(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer_072`
--

INSERT INTO `customer_072` (`id`, `nama_customer`, `alamat`, `no_telp`) VALUES
(1, 'Alfitra', 'Kubang', '0892832761392'),
(2, 'Kazuya', 'Jl. Bandai', '0827671989128'),
(3, 'Bill Gates', 'Jl. Windows', '1234567890');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_072`
--

CREATE TABLE `transaksi_072` (
  `id` int(11) NOT NULL,
  `nama_customer` varchar(50) NOT NULL,
  `menu` varchar(25) NOT NULL,
  `varian_rasa` varchar(50) NOT NULL,
  `tanggal` date NOT NULL,
  `harga` decimal(10,3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaksi_072`
--

INSERT INTO `transaksi_072` (`id`, `nama_customer`, `menu`, `varian_rasa`, `tanggal`, `harga`) VALUES
(13, 'Alfitra', 'Coffe', 'Kopi Filsafat Enjoyer', '2024-06-29', '50.000'),
(14, 'Kazuya', 'Non Coffe', 'Turbo Drink', '2024-07-01', '20.000'),
(15, 'Bill Gates', 'Coffe', 'Elite Global Coffe', '2024-07-02', '10.000');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer_072`
--
ALTER TABLE `customer_072`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transaksi_072`
--
ALTER TABLE `transaksi_072`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer_072`
--
ALTER TABLE `customer_072`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `transaksi_072`
--
ALTER TABLE `transaksi_072`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
