<?php
session_start();
include 'config/config.php';
//cek tombol submit
if(isset($_POST["submit"])) {

    //cek data apakah berhasil ditambahkan
    if(transaksi($_POST) > 0) {
        echo "<script>
            alert('Data Berhasil di Tambahkan ^_^');
            document.location.href='transaksi.php';
            </script>";
       
        } else {
            echo "<script>
            alert('Data Gagal di Tambahkan -_-');
            document.location.href='transaksi.php';
            </script>";
        }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <title>Tambah Transaksi | Pelanggan</title>
</head>
<body>
    <div class="container mt">
    <h1 class="fw-bold fs-3 mt-3">Tambah Data Transaksi</h1>
    <hr>
    <form action="" method="post" class="container-sm">
        <label for="nama_customer" class="form-label">Nama Customer</label>
        <input type="text" class="form-control" name="nama_customer" required/>

        <label for="menu" class="form-label">Menu</label>
        <select name="menu" id="menu" class="form-select">
            <option selected>--Pilih Menu--</option>
            <option value="Coffe">Coffe</option>
            <option value="Non Coffe">Non Coffe</option>
        </select>

        <label for="varian_rasa" class="form-label">Varian Rasa</label>
        <input type="text" class="form-control" name="varian_rasa" required/>

        <label for="tanggal" class="form-label">Tanggal Transaksi</label><br>
        <input type="date"  name="tanggal" required/><br><br>

        <label for="harga" class="form-label">Harga</label>
        <input type="text" class="form-control" name="harga" required/>

        <button type="submit" name="submit" class="btn btn-primary mt-4">Tambah Data</button>
    </form>
</body>
</html>